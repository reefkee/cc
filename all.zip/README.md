[![Hits](https://hits.sh/github.com/skylar69-wtf/CC-CHECKERS-API.svg?label=Visitors)](https://hits.sh/github.com/skylar69-wtf/CC-CHECKERS-API/)

## WARNING : 
This checker does no make charges only authenticate the card.<br>
This scripts are only for educational purpose. If you use this script for other purposes except education we will not be responsible in such cases.<br>

## SOME CHECKERS API

REQUIRED INDEX

HOST ON SERVER OR RUN IT ON XAMPP<br>
:- Reboot

INCLUDES :- 
PAYPAL<br>
SQUAREUP<br>
STRIPE<br>
BRAINTREE<br>
